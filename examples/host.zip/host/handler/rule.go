package handler

import (
	"encoding/json"
	"fmt"
	"io/ioutil"
	"log"
	"net/http"
	"os"
	"path/filepath"
	"strings"

	"github.com/trae/host/model"
)

// RuleManager 管理规则文件的加载和匹配
type RuleManager struct {
	RuleDir         string // 规则文件存储目录
	DefaultResponse string // 默认响应内容
	ruleCache       map[string]*model.RuleFile // 规则缓存，避免频繁读取文件
}

// NewRuleManager 创建规则管理器
func NewRuleManager(ruleDir string, defaultResponse string) *RuleManager {
	// 确保规则目录存在
	if _, err := os.Stat(ruleDir); os.IsNotExist(err) {
		os.MkdirAll(ruleDir, 0755)
	}

	return &RuleManager{
		RuleDir:         ruleDir,
		DefaultResponse: defaultResponse,
		ruleCache:       make(map[string]*model.RuleFile),
	}
}

// GetRuleFile 获取指定域名的规则文件
func (rm *RuleManager) GetRuleFile(domain string) (*model.RuleFile, error) {
	// 检查缓存
	if ruleFile, ok := rm.ruleCache[domain]; ok {
		return ruleFile, nil
	}

	// 构建规则文件路径
	filePath := filepath.Join(rm.RuleDir, domain+".json")

	// 检查文件是否存在
	if _, err := os.Stat(filePath); os.IsNotExist(err) {
		// 如果规则文件不存在，创建默认规则文件
		return rm.createDefaultRuleFile(domain)
	}

	// 读取规则文件
	data, err := ioutil.ReadFile(filePath)
	if err != nil {
		return nil, fmt.Errorf("读取规则文件失败: %v", err)
	}

	// 解析JSON
	var ruleFile model.RuleFile
	if err := json.Unmarshal(data, &ruleFile); err != nil {
		return nil, fmt.Errorf("解析规则文件失败: %v", err)
	}

	// 编译规则中的正则表达式
	for i := range ruleFile.Rules {
		if err := ruleFile.Rules[i].CompileRegex(); err != nil {
			return nil, fmt.Errorf("编译正则表达式失败: %v", err)
		}
	}

	// 更新缓存
	rm.ruleCache[domain] = &ruleFile

	return &ruleFile, nil
}

// createDefaultRuleFile 创建默认规则文件
func (rm *RuleManager) createDefaultRuleFile(domain string) (*model.RuleFile, error) {
	// 创建默认规则文件
	ruleFile := &model.RuleFile{
		Rules: []model.Rule{},
		Default: model.ResponseRule{
			Status:  404,
			Headers: map[string]string{"Content-Type": "text/plain; charset=utf-8"},
			Body:    rm.DefaultResponse,
		},
	}

	// 将规则写入文件
	filePath := filepath.Join(rm.RuleDir, domain+".json")
	data, err := json.MarshalIndent(ruleFile, "", "  ")
	if err != nil {
		return nil, fmt.Errorf("序列化规则失败: %v", err)
	}

	if err := ioutil.WriteFile(filePath, data, 0644); err != nil {
		return nil, fmt.Errorf("写入规则文件失败: %v", err)
	}

	// 更新缓存
	rm.ruleCache[domain] = ruleFile

	return ruleFile, nil
}

// MatchRule 匹配请求与规则
func (rm *RuleManager) MatchRule(req *http.Request) (*model.ResponseRule, error) {
	// 获取域名
	domain := req.Host
	// 移除端口号（如果有）
	if strings.Contains(domain, ":") {
		domain = strings.Split(domain, ":")[0]
	}

	// 获取规则文件
	ruleFile, err := rm.GetRuleFile(domain)
	if err != nil {
		return nil, err
	}

	// 匹配规则
	for i, rule := range ruleFile.Rules {
		if rule.MatchRequest(req) {
			log.Printf("匹配成功: 规则 #%d [%s %s]", i+1, rule.Method, rule.Path)
			return &rule.Response, nil
		}
	}

	// 如果没有匹配的规则，返回默认响应
	log.Printf("未匹配到规则，使用默认响应")
	return &ruleFile.Default, nil
}