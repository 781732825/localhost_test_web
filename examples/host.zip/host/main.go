package main

import (
	"flag"
	"log"
	"os"
	"path/filepath"

	"github.com/trae/host/config"
	"github.com/trae/host/handler"
	"github.com/trae/host/server"
	"github.com/trae/host/utils"
)

func main() {
	// 解析命令行参数
	configPath := flag.String("config", "config.json", "配置文件路径")
	ruleDir := flag.String("rules", "rules", "规则文件目录")
	flag.Parse()

	// 获取可执行文件所在目录
	execDir, err := utils.GetExecutableDir()
	if err != nil {
		log.Fatalf("获取可执行文件目录失败: %v", err)
	}

	// 如果配置文件路径是相对路径，则相对于可执行文件目录
	if !filepath.IsAbs(*configPath) {
		*configPath = filepath.Join(execDir, *configPath)
	}

	// 如果规则目录是相对路径，则相对于可执行文件目录
	if !filepath.IsAbs(*ruleDir) {
		*ruleDir = filepath.Join(execDir, *ruleDir)
	}

	// 确保规则目录存在
	if err := utils.EnsureDir(*ruleDir); err != nil {
		log.Fatalf("创建规则目录失败: %v", err)
	}

	// 加载配置
	log.Printf("加载配置文件: %s", *configPath)
	cfg, err := config.LoadConfig(*configPath)
	if err != nil {
		log.Fatalf("加载配置失败: %v", err)
	}

	// 创建规则管理器
	ruleManager := handler.NewRuleManager(*ruleDir, cfg.DefaultResponse)

	// 创建请求处理器
	requestHandler := handler.NewRequestHandler(ruleManager)

	// 创建服务器
	srv := server.NewServer(cfg, requestHandler)

	// 启动服务器
	log.Println("启动服务器...")
	if err := srv.Start(); err != nil {
		log.Fatalf("启动服务器失败: %v", err)
	}

	// 等待信号
	log.Println("服务器已启动，按Ctrl+C停止")
	utils.WaitForSignal()

	// 停止服务器
	log.Println("正在停止服务器...")
	srv.Stop()

	log.Println("服务器已停止")
	os.Exit(0)
}